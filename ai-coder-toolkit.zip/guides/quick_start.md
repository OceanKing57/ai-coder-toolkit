# 🚀 AI程序员效率宝典 — 5分钟上手指南

## 第一步：配置环境

在终端设置你的AI API Key（任选一个）：

```bash
# DeepSeek（推荐，便宜好用）
export DEEPSEEK_API_KEY="你的key"

# 或者 OpenAI
export OPENAI_API_KEY="你的key"
```

## 第二步：赋予脚本执行权限

```bash
cd ai-coder-toolkit
chmod +x scripts/*.sh
```

## 第三步：开始使用！

### 场景1：写完代码，需要审查
```bash
./scripts/ai_code_review.sh
```
AI会自动读取 `git diff` 并给出审查意见。

### 场景2：提交代码，写commit message
```bash
git add .
./scripts/ai_commit_msg.sh "修复了登录超时问题"
```
AI会根据变更内容生成规范的commit message。

### 场景3：接手新项目，快速理解代码
```bash
./scripts/ai_readme_gen.sh ./src
```
AI会扫描代码结构，生成README。

### 场景4：找Bug
```bash
./scripts/ai_bug_finder.sh ./src
```
AI扫描代码中的潜在问题。

## 进阶玩法

1. **结合Git Hooks**: 在 `.git/hooks/pre-commit` 中加入 `ai_code_review.sh`
2. **整合CI/CD**: 在GitHub Actions中自动运行审查
3. **自定义提示词**: 修改 `prompts/` 目录下的模板

## 常见问题

**Q: 需要付费吗？**
A: 脚本本身免费。使用AI API需要消耗token，DeepSeek约¥0.001/次，GPT-4约¥0.03/次。

**Q: 支持哪些AI？**
A: 支持所有兼容OpenAI API格式的模型：DeepSeek、OpenAI、Claude(通过API)、本地Ollama等。

**Q: 脚本安全吗？**
A: 所有脚本开源可见，只调用AI API，不会上传你的代码到任何第三方服务器（除了AI提供商）。
