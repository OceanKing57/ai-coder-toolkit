#!/bin/bash
# ============================================================
# 脚本名: ai_sql_optimizer.sh
# 功能:   分析SQL语句，使用AI给出性能优化建议和改进方案
# 用法:   ./ai_sql_optimizer.sh [选项]
#         选项:
#           -f <文件>    分析SQL文件
#           -q <查询>    直接分析SQL查询语句
#           --db <类型>  数据库类型: mysql/pg/sqlite/mongo（默认mysql）
#           --explain     同时分析EXPLAIN输出
#           -m <模型>    指定AI模型
# 依赖:   curl, jq
# 环境变量: OPENAI_API_KEY, OPENAI_API_BASE(可选), AI_MODEL(可选)
# ============================================================

set -euo pipefail

API_KEY="${OPENAI_API_KEY:-}"
API_BASE="${OPENAI_API_BASE:-https://api.openai.com/v1}"
MODEL="${AI_MODEL:-gpt-4o-mini}"
SQL_FILE=""
SQL_QUERY=""
DB_TYPE="mysql"
ANALYZE_EXPLAIN=false
EXPLAIN_OUTPUT=""

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

show_help() {
    cat << EOF
${GREEN}AI SQL 优化器${NC} - 智能分析SQL查询性能并给出优化方案

用法: $0 [选项]

选项:
  -f <文件>      分析SQL文件中的查询
  -q <"查询">    直接分析SQL语句（用引号包裹）
  --db <类型>    数据库类型: mysql/postgresql/sqlite/mongodb/oracle（默认mysql）
  --explain      附带EXPLAIN输出进行深度分析
  -m <模型>      指定AI模型
  -h             帮助

示例:
  $0 -f queries.sql                    # 分析SQL文件
  $0 -q "SELECT * FROM users WHERE..." # 直接分析查询
  $0 -f slow.sql --db postgresql       # 指定数据库
  $0 -f query.sql --explain            # 附EXPLAIN分析

提示: 使用 --explain 时，脚本会提示你粘贴EXPLAIN结果
EOF
}

while [[ $# -gt 0 ]]; do
    case $1 in
        -f) SQL_FILE="$2"; shift 2 ;;
        -q) SQL_QUERY="$2"; shift 2 ;;
        --db) DB_TYPE="$2"; shift 2 ;;
        --explain) ANALYZE_EXPLAIN=true; shift ;;
        -m) MODEL="$2"; shift 2 ;;
        -h) show_help; exit 0 ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

check_deps() {
    for cmd in curl jq; do
        command -v "$cmd" &>/dev/null || { echo -e "${RED}缺少: $cmd${NC}"; exit 1; }
    done
    [ -z "$API_KEY" ] && { echo -e "${RED}未设置 OPENAI_API_KEY${NC}"; exit 1; }
    if [ -z "$SQL_FILE" ] && [ -z "$SQL_QUERY" ]; then
        echo -e "${RED}请指定 -f <文件> 或 -q <查询>${NC}"
        exit 1
    fi
}

get_sql() {
    if [ -n "$SQL_QUERY" ]; then
        echo "$SQL_QUERY"
    elif [ -n "$SQL_FILE" ]; then
        [ ! -f "$SQL_FILE" ] && { echo -e "${RED}文件不存在: $SQL_FILE${NC}"; exit 1; }
        cat "$SQL_FILE"
    fi
}

build_prompt() {
    local sql="$1"
    local explain_text="$2"
    
    cat << PROMPT
你是一位资深DBA和SQL优化专家，精通${DB_TYPE}数据库。

请分析以下SQL查询，从以下维度给出优化建议：

1. **索引优化**: 缺失的索引、索引选择、覆盖索引
2. **查询重写**: 子查询优化、JOIN顺序、避免SELECT *
3. **表结构**: 分区建议、数据类型优化、范式化
4. **${DB_TYPE}特性**: 利用数据库特有功能（如MySQL的force index、PG的并行查询等）
5. **执行计划分析**: 全表扫描、文件排序、临时表

输出格式（Markdown表格 + 详细说明）：

| 问题 | 严重度 | 当前行为 | 优化方案 | 预期提升 |
|------|--------|---------|---------|---------|

严重度: 🔴严重 🟡中等 🔵建议

${explain_text:+EXPLAIN输出：}
${explain_text:+```}
${explain_text}
${explain_text:+```}

SQL查询：
\`\`\`sql
$sql
\`\`\`

请用中文输出完整的优化分析报告。
PROMPT
}

call_ai() {
    local prompt="$1"
    local payload
    payload=$(jq -n --arg model "$MODEL" --arg content "$prompt" \
        '{model: $model, messages: [{role: "user", content: $content}], temperature: 0.3, max_tokens: 4096}')
    
    local resp
    resp=$(curl -s -m 120 \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_KEY" \
        -d "$payload" "$API_BASE/chat/completions")
    
    local content
    content=$(echo "$resp" | jq -r '.choices[0].message.content // empty')
    [ -z "$content" ] && { echo -e "${RED}API错误${NC}"; exit 1; }
    echo "$content"
}

main() {
    echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   📊 AI SQL 优化器                  ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
    echo ""
    
    check_deps
    
    echo -e "${GREEN}[1/3]${NC} 获取SQL..."
    local sql
    sql=$(get_sql)
    
    local explain_text=""
    if $ANALYZE_EXPLAIN; then
        echo -e "${YELLOW}请粘贴 EXPLAIN 输出（输入完成后按 Ctrl+D）:${NC}"
        explain_text=$(cat)
    fi
    
    echo -e "${GREEN}[2/3]${NC} AI分析中 (数据库: ${DB_TYPE})..."
    local prompt
    prompt=$(build_prompt "$sql" "$explain_text")
    
    echo -e "${GREEN}[3/3]${NC} 生成优化报告..."
    local report
    report=$(call_ai "$prompt")
    
    echo ""
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${BLUE}        SQL 优化分析报告              ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo "$report"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}✅ 分析完成${NC}"
}

main
