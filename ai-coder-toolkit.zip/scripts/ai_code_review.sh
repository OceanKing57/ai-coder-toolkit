#!/bin/bash
# ============================================
# ai_code_review.sh — AI代码审查助手
# 用法: ./ai_code_review.sh [文件/目录]
# 依赖: curl, jq, OPENAI_API_KEY 或 DEEPSEEK_API_KEY
# ============================================

set -e

# --- 配置 ---
# 优先用DeepSeek（便宜），其次OpenAI
if [ -n "$DEEPSEEK_API_KEY" ]; then
    API_URL="https://api.deepseek.com/v1/chat/completions"
    API_KEY="$DEEPSEEK_API_KEY"
    MODEL="deepseek-chat"
else
    API_URL="https://api.openai.com/v1/chat/completions"
    API_KEY="${OPENAI_API_KEY:?请设置 OPENAI_API_KEY 环境变量}"
    MODEL="gpt-4o-mini"
fi

TARGET="${1:-.}"

# --- 获取diff内容 ---
echo "🔍 正在分析代码变更..."

if git rev-parse --git-dir > /dev/null 2>&1; then
    DIFF=$(git diff --staged 2>/dev/null || git diff)
    if [ -z "$DIFF" ]; then
        echo "⚠️ 没有检测到代码变更（git diff为空）"
        echo "改为分析指定文件: $TARGET"
        if [ -f "$TARGET" ]; then
            DIFF=$(cat "$TARGET")
            FILE_HINT="文件: $TARGET"
        else
            echo "❌ 请提供有效的文件路径或在git仓库中运行"
            exit 1
        fi
    fi
else
    if [ -f "$TARGET" ]; then
        DIFF=$(cat "$TARGET")
        FILE_HINT="文件: $TARGET"
    else
        echo "❌ 不是git仓库，请指定要审查的文件"
        exit 1
    fi
fi

DIFF_PREVIEW=$(echo "$DIFF" | head -3000)

# --- 构建提示词 ---
PROMPT="你是一位资深代码审查专家。请审查以下代码变更，用中文回答：

## 审查要点
1. 🐛 潜在Bug和逻辑错误
2. 🔒 安全漏洞（SQL注入、XSS、敏感信息泄露等）
3. ⚡ 性能问题和优化建议
4. 📐 代码规范和可读性
5. 🧪 缺少的测试覆盖

## 输出格式
用Markdown格式，每个问题标注严重程度（🔴严重 🟡中等 🟢建议）

${FILE_HINT:-}
代码变更：
\`\`\`
$DIFF_PREVIEW
\`\`\`"

# --- 调用AI ---
echo "🤖 AI正在审查..."
RESPONSE=$(curl -s "$API_URL" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $API_KEY" \
    -d "$(jq -n --arg content "$PROMPT" '{
        model: "'$MODEL'",
        messages: [{role: "user", content: $content}],
        temperature: 0.3,
        max_tokens: 2000
    }')")

# --- 输出结果 ---
echo ""
echo "============================================"
echo "  📋 AI 代码审查报告"
echo "============================================"
echo "$RESPONSE" | jq -r '.choices[0].message.content // .error.message // "❌ API调用失败"'
echo ""
echo "============================================"
echo "💡 提示: 严重问题请优先修复，建议问题可渐进优化"
