#!/bin/bash
# ============================================================
# 脚本名: ai_bug_finder.sh
# 功能:   扫描代码文件，使用AI检测潜在bug、安全隐患和代码异味
# 用法:   ./ai_bug_finder.sh [选项] [文件/目录...]
#         选项:
#           -p <模式>  扫描模式: security(安全)/logic(逻辑)/all(全部，默认)
#           -e <扩展名> 指定文件扩展名(如 py,go,js)
#           --severity  最低严重度: high/medium/low（默认medium）
#           -m <模型>   指定AI模型
# 依赖:   curl, jq
# 环境变量: OPENAI_API_KEY, OPENAI_API_BASE(可选), AI_MODEL(可选)
# ============================================================

set -euo pipefail

API_KEY="${OPENAI_API_KEY:-}"
API_BASE="${OPENAI_API_BASE:-https://api.openai.com/v1}"
MODEL="${AI_MODEL:-gpt-4o-mini}"
SCAN_MODE="all"
FILE_EXT=""
MIN_SEVERITY="medium"
TARGETS=()

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

show_help() {
    cat << EOF
${GREEN}AI Bug 探测器${NC} - 让AI帮你找出代码中的潜在问题

用法: $0 [选项] [文件/目录...]

选项:
  -p all|security|logic  扫描模式（默认all）
  -e <扩展名>            限制文件类型（如 py,js,go）
  --severity high|medium|low  最低严重度（默认medium）
  -m <模型>              指定AI模型
  -h                     帮助

示例:
  $0 src/                  # 扫描src目录
  $0 -p security .         # 安全漏洞扫描
  $0 -e go main.go         # 扫描Go文件
  $0 --severity high .     # 只显示高危问题
EOF
}

# 参数解析
while [[ $# -gt 0 ]]; do
    case $1 in
        -p) SCAN_MODE="$2"; shift 2 ;;
        -e) FILE_EXT="$2"; shift 2 ;;
        --severity) MIN_SEVERITY="$2"; shift 2 ;;
        -m) MODEL="$2"; shift 2 ;;
        -h) show_help; exit 0 ;;
        -*) echo "未知选项: $1"; exit 1 ;;
        *) TARGETS+=("$1"); shift ;;
    esac
done

[ ${#TARGETS[@]} -eq 0 ] && TARGETS=(".")

check_deps() {
    for cmd in curl jq; do
        command -v "$cmd" &>/dev/null || { echo -e "${RED}缺少: $cmd${NC}"; exit 1; }
    done
    [ -z "$API_KEY" ] && { echo -e "${RED}未设置 OPENAI_API_KEY${NC}"; exit 1; }
}

# 收集文件
collect_files() {
    local files=()
    local ext_pattern=""
    [ -n "$FILE_EXT" ] && ext_pattern="-name '*.$FILE_EXT'"
    
    for target in "${TARGETS[@]}"; do
        if [ -f "$target" ]; then
            files+=("$target")
        elif [ -d "$target" ]; then
            while IFS= read -r -d '' file; do
                # 跳过常见的非代码文件
                case "$file" in
                    */node_modules/*|*/.git/*|*/vendor/*|*/__pycache__/*|*/target/*|*/dist/*|*/build/*|*.min.js|*.bundle.js) continue ;;
                esac
                files+=("$file")
            done < <(find "$target" -type f \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.go" -o -name "*.java" -o -name "*.rs" -o -name "*.rb" -o -name "*.php" -o -name "*.c" -o -name "*.cpp" -o -name "*.h" -o -name "*.sh" -o -name "*.sql" \) -not -path '*/\.*' -print0 2>/dev/null)
            if [ -n "$FILE_EXT" ]; then
                # 过滤指定扩展名
                local filtered=()
                for f in "${files[@]}"; do
                    [[ "$f" == *.$FILE_EXT ]] && filtered+=("$f")
                done
                files=("${filtered[@]}")
            fi
        fi
    done
    
    # 限制文件数量，最多50个
    if [ ${#files[@]} -gt 50 ]; then
        echo -e "${YELLOW}文件过多(${#files[@]})，仅扫描前50个${NC}"
        files=("${files[@]:0:50}")
    fi
    
    printf '%s\n' "${files[@]}"
}

# 构建提示词
build_prompt() {
    local file_path="$1"
    local content
    content=$(cat "$file_path" 2>/dev/null | head -300)
    [ ${#content} -gt 12000 ] && content="${content:0:12000}"$'\n... (截断)'
    
    local mode_desc="全面检查（安全+逻辑+性能）"
    [ "$SCAN_MODE" = "security" ] && mode_desc="安全漏洞专项检查（注入攻击、敏感信息泄露、权限问题、加密缺陷）"
    [ "$SCAN_MODE" = "logic" ] && mode_desc="逻辑错误专项检查（空指针、边界条件、并发问题、死循环、资源泄漏）"
    
    local severity_instruction=""
    [ "$MIN_SEVERITY" = "high" ] && severity_instruction="只报告高危/严重问题"
    [ "$MIN_SEVERITY" = "low" ] && severity_instruction="报告所有级别的问题"
    [ "$MIN_SEVERITY" = "medium" ] && severity_instruction="报告中危及以上问题"
    
    cat << PROMPT
你是资深的代码安全审计专家。请审查以下代码文件，查找潜在问题。

文件名: $(basename "$file_path")
审查模式: $mode_desc
${severity_instruction:+严重度要求: $severity_instruction}

输出格式（每个问题）：
\`\`\`
[严重度] 第X行 - 问题类型
描述: xxx
风险: xxx
修复建议: xxx
\`\`\`

严重度标记: 🔴高危 🟡中危 🔵低危

如果没有发现问题，输出：✅ 未发现明显问题

代码内容：
\`\`\`
$content
\`\`\`
PROMPT
}

call_ai() {
    local prompt="$1"
    local payload
    payload=$(jq -n --arg model "$MODEL" --arg content "$prompt" \
        '{model: $model, messages: [{role: "user", content: $content}], temperature: 0.2, max_tokens: 2048}')
    
    local resp
    resp=$(curl -s -m 120 \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_KEY" \
        -d "$payload" "$API_BASE/chat/completions")
    
    local content
    content=$(echo "$resp" | jq -r '.choices[0].message.content // empty')
    [ -z "$content" ] && { echo "  ⚠️ API错误"; return 1; }
    echo "$content"
}

main() {
    echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   🐛 AI Bug 探测器                  ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
    echo ""
    
    check_deps
    
    local files
    mapfile -t files < <(collect_files)
    
    if [ ${#files[@]} -eq 0 ]; then
        echo -e "${YELLOW}未找到可扫描的文件${NC}"
        exit 0
    fi
    
    echo -e "${GREEN}找到 ${#files[@]} 个文件待扫描${NC}"
    echo -e "扫描模式: ${YELLOW}$SCAN_MODE${NC}"
    echo ""
    
    local total_issues=0
    local files_with_issues=0
    
    for file in "${files[@]}"; do
        echo -ne "  🔍 $(basename "$file") ... "
        
        local prompt
        prompt=$(build_prompt "$file")
        local result
        result=$(call_ai "$prompt") || { echo "❌"; continue; }
        
        if echo "$result" | grep -q "✅ 未发现"; then
            echo -e "${GREEN}✅ 通过${NC}"
        else
            echo -e "${RED}⚠️ 发现问题${NC}"
            ((files_with_issues++))
            # 统计问题数
            local issues
            issues=$(echo "$result" | grep -c '^\[' || echo 0)
            total_issues=$((total_issues + issues))
            
            echo -e "${BLUE}  ─────────────────────────────────${NC}"
            echo "$result" | while IFS= read -r line; do
                echo "  $line"
            done
            echo -e "${BLUE}  ─────────────────────────────────${NC}"
            echo ""
        fi
    done
    
    echo ""
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "  扫描完成: ${#files[@]} 个文件"
    echo -e "  有问题: ${RED}${files_with_issues}${NC} 个"
    echo -e "  问题总数: ${RED}${total_issues}${NC} 个"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
}

main
