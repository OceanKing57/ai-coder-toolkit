#!/bin/bash
# ============================================================
# 脚本名: ai_config_gen.sh
# 功能:   根据自然语言描述自动生成配置文件(YAML/JSON/TOML/HCL等)
# 用法:   ./ai_config_gen.sh [选项]
#         选项:
#           -d <描述>    配置需求描述（自然语言）
#           -f <格式>    输出格式: yaml/json/toml/hcl/env/nginx（默认yaml）
#           -o <文件>    输出文件路径
#           --validate   生成后尝试验证格式
#           -m <模型>    指定AI模型
# 依赖:   curl, jq, (可选: yamllint/yq/python3用于验证)
# 环境变量: OPENAI_API_KEY, OPENAI_API_BASE(可选), AI_MODEL(可选)
# ============================================================

set -euo pipefail

API_KEY="${OPENAI_API_KEY:-}"
API_BASE="${OPENAI_API_BASE:-https://api.openai.com/v1}"
MODEL="${AI_MODEL:-gpt-4o-mini}"
DESCRIPTION=""
FORMAT="yaml"
OUTPUT_FILE=""
VALIDATE=false

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

show_help() {
    cat << EOF
${GREEN}AI 配置生成器${NC} - 用自然语言描述需求，自动生成配置文件

用法: $0 [选项]

选项:
  -d <"描述">   配置需求描述（必需）
  -f <格式>     输出格式: yaml/json/toml/hcl/env/nginx/docker（默认yaml）
  -o <文件>     输出文件路径（默认输出到终端）
  --validate    生成后验证格式合法性
  -m <模型>     指定AI模型
  -h            帮助

示例:
  $0 -d "Nginx反向代理，转发/api到localhost:3000，开启gzip"
  $0 -d "MySQL连接池配置，最大100连接" -f json -o config.json
  $0 -d "K8s Deployment for Go app, 3 replicas" -f yaml -o deploy.yaml
  $0 -d "Redis集群配置，3主3从" -f yaml --validate

常用格式: yaml(默认), json, toml, env(dotenv), nginx, docker(Dockerfile/docker-compose)
EOF
}

while [[ $# -gt 0 ]]; do
    case $1 in
        -d) DESCRIPTION="$2"; shift 2 ;;
        -f) FORMAT="$2"; shift 2 ;;
        -o) OUTPUT_FILE="$2"; shift 2 ;;
        --validate) VALIDATE=true; shift ;;
        -m) MODEL="$2"; shift 2 ;;
        -h) show_help; exit 0 ;;
        *) echo "未知: $1"; exit 1 ;;
    esac
done

check_deps() {
    for cmd in curl jq; do
        command -v "$cmd" &>/dev/null || { echo -e "${RED}缺少: $cmd${NC}"; exit 1; }
    done
    [ -z "$API_KEY" ] && { echo -e "${RED}未设置 OPENAI_API_KEY${NC}"; exit 1; }
    [ -z "$DESCRIPTION" ] && { echo -e "${RED}必须使用 -d 指定配置描述${NC}"; exit 1; }
}

build_prompt() {
    local format_hint=""
    case "$FORMAT" in
        yaml) format_hint="YAML格式，使用合理的缩进（2空格），包含清晰的注释（# 注释）" ;;
        json) format_hint="JSON格式，严格遵循JSON规范，使用2空格缩进" ;;
        toml) format_hint="TOML格式，合理使用section和key-value" ;;
        env)  format_hint="dotenv格式 (.env)，每行 KEY=VALUE，包含注释" ;;
        nginx) format_hint="Nginx配置格式，包含server/location块" ;;
        docker) format_hint="Docker Compose格式，version 3.8+" ;;
        hcl) format_hint="HCL格式 (Terraform风格)" ;;
        *) format_hint="${FORMAT}格式" ;;
    esac
    
    cat << PROMPT
你是一位资深DevOps/SRE工程师，精通各种配置文件编写。

请根据以下需求生成配置文件：

**需求描述：**
$DESCRIPTION

**输出格式：** $format_hint

**要求：**
1. 配置项要完整、实用，包含常见的最佳实践设置
2. 关键配置项添加中文注释说明
3. 敏感信息使用占位符（如 \${DB_PASSWORD}）
4. 保持配置简洁但不失完整性
5. 考虑生产环境的需求（如健康检查、超时、重试等）

请直接输出配置内容（不要用Markdown代码块包裹）。
PROMPT
}

call_ai() {
    local prompt="$1"
    local payload
    payload=$(jq -n --arg model "$MODEL" --arg content "$prompt" \
        '{model: $model, messages: [{role: "user", content: $content}], temperature: 0.3, max_tokens: 4096}')
    
    local resp
    resp=$(curl -s -m 120 \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_KEY" \
        -d "$payload" "$API_BASE/chat/completions")
    
    local content
    content=$(echo "$resp" | jq -r '.choices[0].message.content // empty')
    [ -z "$content" ] && { echo -e "${RED}API错误${NC}"; exit 1; }
    echo "$content"
}

validate_config() {
    local file="$1"
    local fmt="$2"
    local valid=true
    
    case "$fmt" in
        json)
            if command -v python3 &>/dev/null; then
                python3 -m json.tool "$file" > /dev/null 2>&1 || valid=false
            elif command -v jq &>/dev/null; then
                jq empty "$file" > /dev/null 2>&1 || valid=false
            fi
            ;;
        yaml)
            if command -v python3 &>/dev/null; then
                python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null || valid=false
            fi
            ;;
    esac
    
    if $valid; then
        echo -e "${GREEN}✅ 格式验证通过${NC}"
    else
        echo -e "${YELLOW}⚠️ 格式验证失败（可能缺少验证工具或格式有误）${NC}"
    fi
}

main() {
    echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   ⚙️  AI 配置生成器                  ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
    echo ""
    
    check_deps
    
    echo -e "${GREEN}[1/3]${NC} 解析需求: ${DESCRIPTION:0:60}..."
    echo -e "${GREEN}[2/3]${NC} AI生成配置 (格式: $FORMAT)..."
    
    local prompt
    prompt=$(build_prompt)
    local config
    config=$(call_ai "$prompt")
    
    echo -e "${GREEN}[3/3]${NC} 输出配置..."
    
    if [ -n "$OUTPUT_FILE" ]; then
        echo "$config" > "$OUTPUT_FILE"
        echo -e "${GREEN}✅ 配置已保存到: $OUTPUT_FILE${NC}"
        if $VALIDATE; then
            validate_config "$OUTPUT_FILE" "$FORMAT"
        fi
    else
        echo ""
        echo -e "${BLUE}════════ 生成的配置 ════════${NC}"
        echo "$config"
        echo -e "${BLUE}══════════════════════════${NC}"
        echo -e "${YELLOW}提示: 使用 -o <文件> 保存到文件${NC}"
    fi
}

main
