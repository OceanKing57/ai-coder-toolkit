#!/bin/bash
# ============================================
# ai_commit_msg.sh — AI自动生成Git提交信息
# 用法: ./ai_commit_msg.sh [提示]
# 示例: ./ai_commit_msg.sh "修复登录bug"
# 依赖: curl, jq, git, AI API Key
# ============================================

set -e

# --- 配置 ---
if [ -n "$DEEPSEEK_API_KEY" ]; then
    API_URL="https://api.deepseek.com/v1/chat/completions"
    API_KEY="$DEEPSEEK_API_KEY"
    MODEL="deepseek-chat"
else
    API_URL="https://api.openai.com/v1/chat/completions"
    API_KEY="${OPENAI_API_KEY:?请设置 OPENAI_API_KEY}"
    MODEL="gpt-4o-mini"
fi

HINT="${1:-}"

# --- 检查git仓库 ---
if ! git rev-parse --git-dir > /dev/null 2>&1; then
    echo "❌ 请在git仓库中运行此脚本"
    exit 1
fi

# --- 获取变更 ---
STAGED=$(git diff --staged --stat 2>/dev/null)
UNSTAGED=$(git diff --stat 2>/dev/null)

if [ -z "$STAGED" ] && [ -z "$UNSTAGED" ]; then
    echo "⚠️ 没有检测到代码变更"
    exit 0
fi

# --- 优先看暂存区 ---
if [ -n "$STAGED" ]; then
    DIFF_STAT="$STAGED"
    DIFF_CONTENT=$(git diff --staged | head -3000)
    ZONE="暂存区"
else
    DIFF_STAT="$UNSTAGED"
    DIFF_CONTENT=$(git diff | head -3000)
    ZONE="工作区"
fi

# --- 构建提示词 ---
PROMPT="根据以下Git变更生成一条规范的commit message。

## 格式要求
使用 Conventional Commits 格式：
<type>(<scope>): <subject>

类型: feat/fix/docs/refactor/test/chore/perf/style
主题: 简洁描述（50字以内），中文

${HINT:+"额外提示: $HINT"}

## 变更文件
$DIFF_STAT

## 变更内容（部分）
\`\`\`diff
$DIFF_CONTENT
\`\`\`

请只返回commit message本身，不要加任何解释。"

echo "📝 分析 $ZONE 变更..."

# --- 调用AI ---
RESPONSE=$(curl -s "$API_URL" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $API_KEY" \
    -d "$(jq -n --arg content "$PROMPT" '{
        model: "'$MODEL'",
        messages: [{role: "user", content: $content}],
        temperature: 0.3,
        max_tokens: 200
    }')")

COMMIT_MSG=$(echo "$RESPONSE" | jq -r '.choices[0].message.content // ""' | tr -d '"' | xargs)

echo ""
echo "============================================"
echo "  建议的 Commit Message:"
echo "============================================"
echo "  $COMMIT_MSG"
echo "============================================"
echo ""
echo "执行以下命令使用此消息:"
echo "  git commit -m \"$COMMIT_MSG\""
