#!/bin/bash
# ============================================================
# 脚本名: ai_readme_gen.sh
# 功能:   自动扫描项目结构和代码，生成专业的README.md文档
# 用法:   ./ai_readme_gen.sh [选项]
#         选项:
#           -d <目录>  指定项目目录（默认当前目录）
#           -o <文件>  输出文件路径（默认 ./README.md）
#           -l <语言>  文档语言 zh/en（默认zh）
#           -m <模型>  指定AI模型
#           --dry-run  仅打印到终端，不写入文件
# 依赖:   curl, jq
# 环境变量: OPENAI_API_KEY, OPENAI_API_BASE(可选), AI_MODEL(可选)
# ============================================================

set -euo pipefail

# ---- 配置 ----
API_KEY="${OPENAI_API_KEY:-}"
API_BASE="${OPENAI_API_BASE:-https://api.openai.com/v1}"
MODEL="${AI_MODEL:-gpt-4o-mini}"
PROJECT_DIR="."
OUTPUT_FILE="README.md"
LANGUAGE="zh"
DRY_RUN=false

# ---- 颜色 ----
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

show_help() {
    cat << EOF
${GREEN}AI README生成器${NC} - 从你的代码中自动生成专业README

用法: $0 [选项]

选项:
  -d <目录>    项目根目录（默认: 当前目录）
  -o <文件>    输出文件（默认: README.md）
  -l zh|en     文档语言（默认: zh）
  -m <模型>    指定AI模型
  --dry-run    预览模式，不写文件
  -h           帮助

示例:
  $0                           # 在当前目录生成README.md
  $0 -d ~/myproject -l en     # 指定目录，英文文档
  $0 --dry-run                 # 预览不写入
EOF
}

# 参数解析
while [[ $# -gt 0 ]]; do
    case $1 in
        -d) PROJECT_DIR="$2"; shift 2 ;;
        -o) OUTPUT_FILE="$2"; shift 2 ;;
        -l) LANGUAGE="$2"; shift 2 ;;
        -m) MODEL="$2"; shift 2 ;;
        --dry-run) DRY_RUN=true; shift ;;
        -h) show_help; exit 0 ;;
        *) echo -e "${RED}未知参数: $1${NC}"; exit 1 ;;
    esac
done

# 检查
check_deps() {
    for cmd in curl jq; do
        if ! command -v "$cmd" &>/dev/null; then
            echo -e "${RED}缺少依赖: $cmd${NC}"; exit 1
        fi
    done
    if [ -z "$API_KEY" ]; then
        echo -e "${RED}未设置 OPENAI_API_KEY${NC}"; exit 1
    fi
    if [ ! -d "$PROJECT_DIR" ]; then
        echo -e "${RED}目录不存在: $PROJECT_DIR${NC}"; exit 1
    fi
}

# 扫描项目结构
scan_project() {
    cd "$PROJECT_DIR"
    
    echo -e "${GREEN}正在扫描项目结构...${NC}"
    
    # 目录树（限制深度4层，忽略隐藏文件和node_modules等）
    local tree
    tree=$(find . -maxdepth 4 -not -path '*/\.*' \
        -not -path '*/node_modules/*' \
        -not -path '*/vendor/*' \
        -not -path '*/__pycache__/*' \
        -not -path '*/target/*' \
        -not -path '*/.git/*' \
        -not -path '*/dist/*' \
        -not -path '*/build/*' \
        -type f | head -200 | sort)
    
    # 包管理器文件
    local pkg_files=""
    for f in package.json go.mod Cargo.toml requirements.txt pom.xml build.gradle Makefile CMakeLists.txt; do
        [ -f "$f" ] && pkg_files+="$f"$'\n'
    done
    
    # 关键源文件内容（取样）
    local source_samples=""
    local sample_count=0
    while IFS= read -r file; do
        [ $sample_count -ge 8 ] && break
        if [[ "$file" =~ \.(go|py|js|ts|java|rs|rb|php|c|cpp|h)$ ]]; then
            local content
            content=$(head -60 "$file" 2>/dev/null || true)
            if [ -n "$content" ]; then
                source_samples+="=== $file ===
$content

"
                ((sample_count++))
            fi
        fi
    done <<< "$tree"
    
    # 现有的README
    local existing_readme=""
    [ -f "README.md" ] && existing_readme=$(head -100 "README.md" 2>/dev/null || true)
    [ -f "README" ] && existing_readme=$(head -100 "README" 2>/dev/null || true)
    
    cat << DATA
## 项目文件结构
$tree

## 包管理文件
$pkg_files

## 源码样本
$source_samples

## 现有README
$existing_readme
DATA
}

# 构建提示词
build_prompt() {
    local data="$1"
    local lang_hint="中文"
    [ "$LANGUAGE" = "en" ] && lang_hint="英文"
    
    cat << PROMPT
你是一位技术文档专家。请根据以下项目信息生成一份专业的README.md文档。

要求：
1. 使用${lang_hint}撰写
2. 包含以下章节（根据实际情况调整）：
   - 项目名称和一句话描述
   - 功能特性
   - 技术栈
   - 快速开始（安装、配置、运行）
   - 项目结构说明
   - API文档入口（如果有）
   - 贡献指南
   - 许可证
3. 使用Markdown格式，包含适量emoji使文档生动
4. 代码示例使用正确的语言标记
5. 对于不确定的部分使用 [待补充] 标记

项目信息：
$data

请直接输出README.md的完整内容（不要用代码块包裹）。
PROMPT
}

# 调用AI
call_ai() {
    local prompt="$1"
    local payload
    payload=$(jq -n \
        --arg model "$MODEL" \
        --arg content "$prompt" \
        '{model: $model, messages: [{role: "user", content: $content}], temperature: 0.6, max_tokens: 4096}')
    
    local resp
    resp=$(curl -s -m 180 \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $API_KEY" \
        -d "$payload" \
        "$API_BASE/chat/completions")
    
    local content
    content=$(echo "$resp" | jq -r '.choices[0].message.content // empty')
    [ -z "$content" ] && { echo -e "${RED}API错误: $(echo "$resp" | jq -r '.error.message // "未知"')${NC}"; exit 1; }
    echo "$content"
}

# 主流程
main() {
    echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   📝 AI README 自动生成器           ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
    echo ""
    
    check_deps
    
    echo -e "${GREEN}[1/3]${NC} 扫描项目: $PROJECT_DIR"
    local scan_data
    scan_data=$(scan_project)
    
    echo -e "${GREEN}[2/3]${NC} AI正在生成README文档..."
    local prompt
    prompt=$(build_prompt "$scan_data")
    
    echo -e "${GREEN}[3/3]${NC} 调用AI模型: $MODEL"
    local readme
    readme=$(call_ai "$prompt")
    
    if $DRY_RUN; then
        echo ""
        echo -e "${BLUE}════════ 预览 ════════${NC}"
        echo "$readme"
        echo -e "${BLUE}══════════════════════${NC}"
        echo -e "${YELLOW}这是预览模式，未写入文件${NC}"
    else
        local out_path="$PROJECT_DIR/$OUTPUT_FILE"
        echo "$readme" > "$out_path"
        echo ""
        echo -e "${GREEN}✅ README已生成: ${out_path}${NC}"
    fi
}

main
