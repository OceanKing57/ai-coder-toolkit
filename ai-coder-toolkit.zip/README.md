# AI程序员效率宝典 v1.0

> 30个AI辅助编程工具，让你每天早下班2小时  
> 价格：¥19.9 | 一次购买，永久更新

---

## 📦 产品包含

| 类别 | 数量 | 说明 |
|------|:--:|------|
| 🔧 实战脚本 | 10个 | Shell/Python脚本，复制即用 |
| 💬 AI提示词 | 20个 | 覆盖代码审查/调试/重构/文档 |
| 📖 教程指南 | 3篇 | 从入门到高级 |

## 🚀 5分钟快速开始

1. 下载整个 `scripts/` 目录
2. `chmod +x scripts/*.sh`
3. 设置你的 AI API Key 环境变量（支持 OpenAI / DeepSeek / Claude）
4. 开始使用！

```bash
# 示例：AI审查你的代码改动
./scripts/ai_code_review.sh

# 示例：AI生成commit message
./scripts/ai_commit_msg.sh "feat: 新增用户登录模块"
```

## 🎯 适用人群

- 每天写重复代码想提效的开发者
- 想做Code Review但没时间的团队Lead
- 经常忘记写测试和文档的程序员
- 想用AI但不是怎么调prompt的新手

## 📋 完整目录

```
ai-coder-toolkit/
├── README.md           ← 你在这里
├── VERSION
├── scripts/            ← 10个实战脚本
│   ├── ai_code_review.sh
│   ├── ai_commit_msg.sh
│   ├── ai_readme_gen.sh
│   ├── ai_bug_finder.sh
│   ├── ai_sql_optimizer.sh
│   ├── ai_config_gen.sh
│   ├── ai_log_analyzer.sh
│   ├── ai_doc_translator.sh
│   ├── ai_test_gen.sh
│   └── ai_shell_helper.sh
├── prompts/            ← 20个提示词模板
│   ├── code_review/
│   ├── debugging/
│   ├── refactoring/
│   └── documentation/
└── guides/             ← 3篇教程
    ├── quick_start.md
    ├── advanced.md
    └── faq.md
```

## 💡 支持的大模型

- OpenAI GPT-4 / GPT-4o
- Anthropic Claude 3.5 / Claude 4
- DeepSeek V3 / R1
- 任何兼容 OpenAI API 格式的模型

## 🔄 更新日志

见 `VERSION` 文件

---

> 小琳出品 | 买一次永久更新 | 扫码 ¥19.9
